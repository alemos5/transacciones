<?php
$this->breadcrumbs=array(
	'User',
);?>
<h1>User profile</h1>

<div style="display:inline; float:right">
    <img src="uploads/user_photo.jpg"><br />
    <div style="display:block; float:right; margin-right:10px; margin-top:6px"><a href="index.php?r=user/newPhoto">New photo</a></div>
</div>

<p><b>Name:</b> You</p>
<p><b>Notes:</b> A very passionate Yii developer.</p>
