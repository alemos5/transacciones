<?php $this->pageTitle=Yii::app()->name; ?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i>!</h1>

<p>The application is a simple example of how to configure <b>yii-jpegcam</b> widget.
It emulates a user profile where you can change the picture.</p>

<p><a href="index.php?r=user/index">Click here</a> to start!</p>
