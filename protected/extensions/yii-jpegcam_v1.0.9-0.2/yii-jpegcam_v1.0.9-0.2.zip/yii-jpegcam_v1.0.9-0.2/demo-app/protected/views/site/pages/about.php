<?php
$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<h1>About</h1>

<p><b>yii-jpegcam</b> is a widget that wraps <a href="http://code.google.com/p/jpegcam/">jpegcam</a> (see <a href="http://code.google.com/p/jpegcam/wiki/APIDocs">documentation</a>).</p>

<p></p>

<p>You can find <a href="https://github.com/atti84it/yii-jpegcam">yii-jpegcam on Github.com</a>.</p>

<p>yii-jpegcam developer's <a href="http://amberdev.altervista.org/">home page</a>.</p>
